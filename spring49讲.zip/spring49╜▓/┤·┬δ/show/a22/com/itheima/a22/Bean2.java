package com.itheima.a22;

public class Bean2 {
    public void foo(String name, int age) {

    }
}
