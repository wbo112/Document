package com.itheima.a23.sub;

class EmployeeDao extends BaseDao {
}
