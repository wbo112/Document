package com.itheima.a23.sub;

class Student {
}
