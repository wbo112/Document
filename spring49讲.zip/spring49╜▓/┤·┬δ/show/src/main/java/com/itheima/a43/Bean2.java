package com.itheima.a43;

import org.springframework.stereotype.Component;

@Component
public class Bean2 {
}
