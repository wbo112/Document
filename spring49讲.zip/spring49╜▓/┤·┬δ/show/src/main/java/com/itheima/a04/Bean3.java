package com.itheima.a04;

public class Bean3 {
}
