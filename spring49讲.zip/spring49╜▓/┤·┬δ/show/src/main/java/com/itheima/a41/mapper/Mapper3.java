package com.itheima.a41.mapper;

public interface Mapper3 {
}
