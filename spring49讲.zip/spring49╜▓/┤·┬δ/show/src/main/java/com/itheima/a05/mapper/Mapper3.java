package com.itheima.a05.mapper;

public class Mapper3 {
}
