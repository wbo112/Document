package com.itheima.a23.sub;

class BaseDao<T> {
    T findOne() {
        return null;
    }
}
