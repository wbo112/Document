# coding:utf8


def city_with_category(data):
    return data['areaName'] + "_" + data['category']
