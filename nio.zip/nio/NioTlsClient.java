package com.wbo112.nio;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

public class NioTlsClient {

    private static final String TRUSTSTORE_PATH = "client.truststore";
    private static final String TRUSTSTORE_PASSWORD = "password";

    public static void main(String[] args) throws Exception {
        SSLContext sslContext = createSslContext();

        SocketChannel channel = SocketChannel.open();
        channel.configureBlocking(false);
        channel.connect(new InetSocketAddress("localhost", 8443));

        Selector selector = Selector.open();
        channel.register(selector, SelectionKey.OP_CONNECT);

        TlsConnection conn = new TlsConnection(channel, sslContext.createSSLEngine("localhost", 8443));
        conn.sslEngine.setUseClientMode(true);

        while (true) {
            selector.select();
            var keys = selector.selectedKeys().iterator();
            while (keys.hasNext()) {
                SelectionKey key = keys.next();
                keys.remove();

                if (key.isConnectable()) {
                    if (channel.finishConnect()) {
                        key.interestOps(SelectionKey.OP_READ);
                        conn.beginHandshake();
                        // 发送测试消息
                        conn.sendResponse("Hello from NIO TLS Client!");
                    }
                } else if (key.isReadable()) {
                    conn.read(); // 会打印服务器回复
                    // 收到回复后退出（演示用）
                    Thread.sleep(500);
                    channel.close();
                    return;
                }
            }
        }
    }

    private static SSLContext createSslContext() throws Exception {
        KeyStore ts = KeyStore.getInstance("JKS");
        try (var in = NioTlsClient.class.getClassLoader().getResourceAsStream(TRUSTSTORE_PATH)) {
            ts.load(in, TRUSTSTORE_PASSWORD.toCharArray());
        }

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ts);

        SSLContext context = SSLContext.getInstance("TLS");
        context.init(null, tmf.getTrustManagers(), null);
        return context;
    }
}