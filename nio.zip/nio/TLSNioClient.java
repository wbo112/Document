package com.wbo112.nio;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;

public class TLSNioClient {
    private static final String HOST = "localhost";
    private static final int PORT = 8443;
    
    private SSLContext sslContext;
    private Selector selector;
    private TLSChannel tlsChannel;
    
    public TLSNioClient() throws Exception {
        initSSLContext();
        initSelector();
    }
    
    private void initSSLContext() throws Exception {
        sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(
                    java.security.cert.X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(
                    java.security.cert.X509Certificate[] certs, String authType) {
                }
            }
        }, null);
    }
    
    private void initSelector() throws IOException {
        selector = Selector.open();
        connectToServer();
    }
    
    private void connectToServer() throws IOException {
        SocketChannel socketChannel = SocketChannel.open();
        socketChannel.configureBlocking(false);
        socketChannel.connect(new InetSocketAddress(HOST, PORT));
        
        SSLEngine sslEngine = sslContext.createSSLEngine(HOST, PORT);
        sslEngine.setUseClientMode(true);
        
        tlsChannel = new TLSChannel(socketChannel, sslEngine);
        socketChannel.register(selector, SelectionKey.OP_CONNECT, tlsChannel);
    }
    
    public void start() throws IOException {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            selector.select(1000); // 1 second timeout
            
            Set<SelectionKey> selectedKeys = selector.selectedKeys();
            Iterator<SelectionKey> iter = selectedKeys.iterator();
            
            while (iter.hasNext()) {
                SelectionKey key = iter.next();
                iter.remove();
                
                if (key.isConnectable()) {
                    finishConnection(key);
                } else if (key.isReadable()) {
                    handleRead(key);
                }
            }
            
            // Handle user input
            if (System.in.available() > 0) {
                String input = scanner.nextLine();
                if ("quit".equalsIgnoreCase(input)) {
                    break;
                }
                if (tlsChannel != null && tlsChannel.isHandshakeFinished()) {
                    tlsChannel.write(input);
                }
            }
        }
        
        if (tlsChannel != null) {
            tlsChannel.close();
        }
        scanner.close();
    }
    
    private void finishConnection(SelectionKey key) throws IOException {
        SocketChannel socketChannel = (SocketChannel) key.channel();
        
        try {
            if (socketChannel.finishConnect()) {
                TLSChannel tlsChannel = (TLSChannel) key.attachment();
                tlsChannel.getSslEngine().beginHandshake();
                key.interestOps(SelectionKey.OP_READ);
                System.out.println("Connected to server");
            }
        } catch (Exception e) {
            System.err.println("Connection failed: " + e.getMessage());
            key.cancel();
        }
    }
    
    private void handleRead(SelectionKey key) throws IOException {
        TLSChannel tlsChannel = (TLSChannel) key.attachment();
        
        try {
            if (tlsChannel.getSslEngine().getHandshakeStatus() != SSLEngineResult.HandshakeStatus.FINISHED) {
                if (!tlsChannel.doHandshake()) {
                    return;
                }
                System.out.println("TLS handshake completed");
            }
            
            String message = tlsChannel.read();
            if (message != null) {
                System.out.println("Server: " + message);
            }
        } catch (Exception e) {
            System.err.println("Error reading from server: " + e.getMessage());
            tlsChannel.close();
            key.cancel();
        }
    }
    
    public static void main(String[] args) throws Exception {
        new TLSNioClient().start();
    }
}