package com.wbo112.nio;

import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.security.KeyStore;
import java.util.Iterator;
import java.util.Set;

public class TLSNioServer {
    private static final int PORT = 8443;
    private static final String KEYSTORE_PATH = "server.keystore";
    private static final String KEYSTORE_PASSWORD = "password";
    
    private SSLContext sslContext;
    private Selector selector;
    
    public TLSNioServer() throws Exception {
        initSSLContext();
        initSelector();
    }
    
    private void initSSLContext() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("JKS");
        try (FileInputStream fis = new FileInputStream(KEYSTORE_PATH)) {
            keyStore.load(fis, KEYSTORE_PASSWORD.toCharArray());
        }
        
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(keyStore, KEYSTORE_PASSWORD.toCharArray());
        
        sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), null, null);
    }
    
    private void initSelector() throws IOException {
        selector = Selector.open();
        ServerSocketChannel serverChannel = ServerSocketChannel.open();
        serverChannel.configureBlocking(false);
        serverChannel.socket().bind(new InetSocketAddress(PORT));
        serverChannel.register(selector, SelectionKey.OP_ACCEPT);
        System.out.println("TLS Server started on port " + PORT);
    }
    
    public void start() throws IOException {
        while (true) {
            selector.select();
            Set<SelectionKey> selectedKeys = selector.selectedKeys();
            Iterator<SelectionKey> iter = selectedKeys.iterator();
            
            while (iter.hasNext()) {
                SelectionKey key = iter.next();
                iter.remove();
                
                if (key.isAcceptable()) {
                    acceptConnection(key);
                } else if (key.isReadable()) {
                    handleRead(key);
                }
            }
        }
    }
    
    private void acceptConnection(SelectionKey key) throws IOException {
        ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
        SocketChannel clientChannel = serverChannel.accept();
        clientChannel.configureBlocking(false);
        
        SSLEngine sslEngine = sslContext.createSSLEngine();
        sslEngine.setUseClientMode(false);
        sslEngine.beginHandshake();
        
        TLSChannel tlsChannel = new TLSChannel(clientChannel, sslEngine);
        clientChannel.register(selector, SelectionKey.OP_READ, tlsChannel);
        
        System.out.println("Accepted connection from: " + clientChannel.getRemoteAddress());
    }
    
    private void handleRead(SelectionKey key) throws IOException {
        TLSChannel tlsChannel = (TLSChannel) key.attachment();
        
        try {
            if (tlsChannel.getSslEngine().getHandshakeStatus() != SSLEngineResult.HandshakeStatus.FINISHED) {
                if (!tlsChannel.doHandshake()) {
                    return;
                }
            }
            
            String message = tlsChannel.read();
            if (message != null) {
                System.out.println("Received: " + message);
                // Echo back the message
                tlsChannel.write("Echo: " + message);
            }
        } catch (Exception e) {
            System.err.println("Error handling client: " + e.getMessage());
            tlsChannel.close();
            key.cancel();
        }
    }
    
    public static void main(String[] args) throws Exception {
        new TLSNioServer().start();
    }
}