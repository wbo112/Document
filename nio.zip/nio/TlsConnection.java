package com.wbo112.nio;

import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLEngineResult;
import javax.net.ssl.SSLException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;

/**
 * 封装基于 SSLEngine 的非阻塞 TLS 连接。
 * 支持握手、加密读写，处理半包/粘包。
 */
public class TlsConnection {

    private final SocketChannel channel;
    final SSLEngine sslEngine;

    // 应用数据缓冲区（明文）
    private final ByteBuffer appData;

    // 网络数据发送缓冲区（加密后）
    private final ByteBuffer netOutBuffer;

    // 网络数据接收缓冲区（累积未处理的加密数据）
    private ByteBuffer netInBuffer;

    public TlsConnection(SocketChannel channel, SSLEngine sslEngine) {
        this.channel = channel;
        this.sslEngine = sslEngine;

        int appBufferSize = sslEngine.getSession().getApplicationBufferSize();
        int netBufferSize = sslEngine.getSession().getPacketBufferSize();

        this.appData = ByteBuffer.allocate(appBufferSize);
        this.netOutBuffer = ByteBuffer.allocate(netBufferSize);
        this.netInBuffer = ByteBuffer.allocate(netBufferSize);
    }

    /**
     * 开始 TLS 握手（必须在连接建立后调用）
     */
    public void beginHandshake() throws IOException {
        sslEngine.beginHandshake();
        processHandshake();
    }

    /**
     * 处理 TLS 握手状态机
     */
    private void processHandshake() throws IOException {
        SSLEngineResult.HandshakeStatus hsStatus = sslEngine.getHandshakeStatus();

        while (hsStatus != SSLEngineResult.HandshakeStatus.FINISHED &&
                hsStatus != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {

            switch (hsStatus) {
                case NEED_TASK:
                    Runnable task;
                    while ((task = sslEngine.getDelegatedTask()) != null) {
                        task.run();
                    }
                    hsStatus = sslEngine.getHandshakeStatus();
                    break;

                case NEED_WRAP:
                    // 发送握手数据（如 ServerHello, Certificate 等）
                    netOutBuffer.clear();
                    SSLEngineResult wrapResult = sslEngine.wrap(ByteBuffer.allocate(0), netOutBuffer);
                    if (wrapResult.getStatus() != SSLEngineResult.Status.OK) {
                        throw new SSLException("Handshake wrap failed: " + wrapResult.getStatus());
                    }
                    netOutBuffer.flip();
                    while (netOutBuffer.hasRemaining()) {
                        channel.write(netOutBuffer);
                    }
                    hsStatus = sslEngine.getHandshakeStatus();
                    break;

                case NEED_UNWRAP:
                    // 读取并处理对方发来的握手数据
                    ensureNetInBufferCapacity(1); // 至少留1字节空间
                    int bytesRead = channel.read(netInBuffer);
                    if (bytesRead < 0) {
                        throw new IOException("Connection closed during handshake");
                    }

                    netInBuffer.flip();
                    appData.clear();
                    SSLEngineResult unwrapResult = sslEngine.unwrap(netInBuffer, appData);
                    netInBuffer.compact(); // 保留未消费的数据到 buffer 开头

                    switch (unwrapResult.getStatus()) {
                        case OK:
                            // 成功解包，继续握手
                            break;
                        case BUFFER_UNDERFLOW:
                            // 数据不足，继续等待更多数据（不报错！）
                            continue;
                        default:
                            throw new SSLException("Handshake unwrap failed: " + unwrapResult.getStatus());
                    }
                    hsStatus = sslEngine.getHandshakeStatus();
                    break;

                default:
                    throw new IllegalStateException("Unexpected handshake status: " + hsStatus);
            }
        }
        System.out.println("TLS handshake completed with " + channel.getRemoteAddress());
    }

    /**
     * 从通道读取加密数据，解密后处理应用数据
     */
    public void read() throws IOException {
        // 1. 从 SocketChannel 读取更多加密数据
        ensureNetInBufferCapacity(1);
        int bytesRead = channel.read(netInBuffer);
        if (bytesRead == -1) {
            channel.close();
            return;
        }
        if (bytesRead == 0) {
            return; // 无数据可读
        }

        // 2. 尝试反复解密，直到数据不足或无应用数据
        netInBuffer.flip();
        while (netInBuffer.hasRemaining()) {
            appData.clear();
            SSLEngineResult result = sslEngine.unwrap(netInBuffer, appData);

            switch (result.getStatus()) {
                case OK:
                    appData.flip();
                    if (appData.hasRemaining()) {
                        String message = StandardCharsets.UTF_8.decode(appData).toString();
                        System.out.println("Received: " + message.trim());
                        sendResponse("Echo: " + message.trim());
                    }
                    break;

                case BUFFER_UNDERFLOW:
                    // 数据不够，保留剩余数据，退出循环等待下次 read
                    netInBuffer.compact();
                    return;

                case BUFFER_OVERFLOW:
                    // 应用缓冲区太小（理论上不会发生，因已按 session 分配）
                    throw new SSLException("Application buffer overflow");

                case CLOSED:
                    channel.close();
                    return;
            }
        }

        // 所有数据已消费完毕
        netInBuffer.clear();
    }

    /**
     * 发送明文响应（自动加密并通过 channel 写出）
     */
    public void sendResponse(String response) throws IOException {
        byte[] data = (response + "\n").getBytes(StandardCharsets.UTF_8);
        appData.clear();
        if (data.length > appData.capacity()) {
            throw new IllegalArgumentException("Message too large");
        }
        appData.put(data);
        appData.flip();

        netOutBuffer.clear();
        SSLEngineResult result = sslEngine.wrap(appData, netOutBuffer);
        if (result.getStatus() != SSLEngineResult.Status.OK) {
            throw new SSLException("Wrap failed: " + result.getStatus());
        }
        netOutBuffer.flip();

        while (netOutBuffer.hasRemaining()) {
            channel.write(netOutBuffer);
        }
    }

    /**
     * 确保 netInBuffer 有足够的剩余空间
     */
    private void ensureNetInBufferCapacity(int needed) {
        if (netInBuffer.remaining() < needed) {
            // 扩容：新容量 = 当前容量 * 2 或 满足 needed
            int newCapacity = Math.max(netInBuffer.capacity() * 2, netInBuffer.position() + needed);
            ByteBuffer newBuf = ByteBuffer.allocate(newCapacity);
            netInBuffer.flip();
            newBuf.put(netInBuffer);
            netInBuffer = newBuf;
        }
    }
}