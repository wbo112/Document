package com.wbo112.nio;

import javax.net.ssl.*;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class TLSChannel {
    private static final int BUFFER_SIZE = 16 * 1024;
    
    private SocketChannel socketChannel;
    private SSLEngine sslEngine;
    private ByteBuffer netInBuffer;
    private ByteBuffer netOutBuffer;
    private ByteBuffer appInBuffer;
    private ByteBuffer appOutBuffer;
    
    public TLSChannel(SocketChannel socketChannel, SSLEngine sslEngine) {
        this.socketChannel = socketChannel;
        this.sslEngine = sslEngine;
        
        SSLSession session = sslEngine.getSession();
        netInBuffer = ByteBuffer.allocate(session.getPacketBufferSize());
        netOutBuffer = ByteBuffer.allocate(session.getPacketBufferSize());
        appInBuffer = ByteBuffer.allocate(session.getApplicationBufferSize());
        appOutBuffer = ByteBuffer.allocate(session.getApplicationBufferSize());
        
        appInBuffer.flip(); // Prepare for reading
    }
    
    public boolean doHandshake() throws IOException {
        SSLEngineResult.HandshakeStatus handshakeStatus = sslEngine.getHandshakeStatus();
        
        switch (handshakeStatus) {
            case NEED_WRAP:
                netOutBuffer.clear();
                SSLEngineResult wrapResult = sslEngine.wrap(appOutBuffer, netOutBuffer);
                netOutBuffer.flip();
                
                while (netOutBuffer.hasRemaining()) {
                    socketChannel.write(netOutBuffer);
                }
                
                if (wrapResult.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.FINISHED) {
                    return true;
                }
                break;
                
            case NEED_UNWRAP:
                int bytesRead = socketChannel.read(netInBuffer);
                if (bytesRead > 0) {
                    netInBuffer.flip();
                    SSLEngineResult unwrapResult = sslEngine.unwrap(netInBuffer, appInBuffer);
                    netInBuffer.compact();
                    
                    if (unwrapResult.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.FINISHED) {
                        return true;
                    }
                }
                break;
                
            case NEED_TASK:
                Runnable task;
                while ((task = sslEngine.getDelegatedTask()) != null) {
                    task.run();
                }
                break;
                
            case FINISHED:
                return true;
                
            case NOT_HANDSHAKING:
                return true;
        }
        
        return sslEngine.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.FINISHED;
    }
    
    public String read() throws IOException {
        // First, try to read from application buffer
        if (appInBuffer.hasRemaining()) {
            return readFromAppBuffer();
        }
        
        // Read from network
        netInBuffer.clear();
        int bytesRead = socketChannel.read(netInBuffer);
        if (bytesRead > 0) {
            netInBuffer.flip();
            SSLEngineResult result = sslEngine.unwrap(netInBuffer, appInBuffer);
            netInBuffer.compact();
            
            if (result.getStatus() == SSLEngineResult.Status.OK) {
                appInBuffer.flip();
                return readFromAppBuffer();
            }
        } else if (bytesRead == -1) {
            throw new IOException("Connection closed by peer");
        }
        
        return null;
    }
    
    private String readFromAppBuffer() {
        if (!appInBuffer.hasRemaining()) {
            return null;
        }
        
        byte[] data = new byte[appInBuffer.remaining()];
        appInBuffer.get(data);
        appInBuffer.clear();
        return new String(data).trim();
    }
    
    public void write(String message) throws IOException {
        appOutBuffer.clear();
        appOutBuffer.put(message.getBytes());
        appOutBuffer.flip();
        
        netOutBuffer.clear();
        SSLEngineResult result = sslEngine.wrap(appOutBuffer, netOutBuffer);
        
        if (result.getStatus() == SSLEngineResult.Status.OK) {
            netOutBuffer.flip();
            while (netOutBuffer.hasRemaining()) {
                socketChannel.write(netOutBuffer);
            }
        }
    }
    
    public boolean isHandshakeFinished() {
        return sslEngine.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.FINISHED;
    }
    
    public SSLEngine getSslEngine() {
        return sslEngine;
    }
    
    public void close() throws IOException {
        sslEngine.closeOutbound();
        socketChannel.close();
    }
}