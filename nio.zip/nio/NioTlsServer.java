package com.wbo112.nio;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.*;
import java.security.KeyStore;
import java.util.Iterator;
import java.util.Set;

public class NioTlsServer {

    private static final int PORT = 8443;
    private static final String KEYSTORE_PATH = "server.jks";
    private static final String KEYSTORE_PASSWORD = "password";

    public static void main(String[] args) throws Exception {
        // 1. 创建 SSLContext
        SSLContext sslContext = createSslContext();

        // 2. 创建 ServerSocketChannel（非阻塞）
        ServerSocketChannel serverChannel = ServerSocketChannel.open();
        serverChannel.configureBlocking(false);
        serverChannel.bind(new InetSocketAddress(PORT));

        // 3. 创建 Selector
        Selector selector = Selector.open();
        serverChannel.register(selector, SelectionKey.OP_ACCEPT);

        System.out.println("TLS NIO Server listening on port " + PORT);

        while (true) {
            selector.select();
            Set<SelectionKey> selectedKeys = selector.selectedKeys();
            Iterator<SelectionKey> iter = selectedKeys.iterator();

            while (iter.hasNext()) {
                SelectionKey key = iter.next();
                iter.remove();

                if (key.isAcceptable()) {
                    handleAccept(serverChannel, selector, sslContext);
                } else if (key.isReadable()) {
                    handleRead(key);
                } else if (key.isWritable()) {
                    handleWrite(key);
                }
            }
        }
    }

    private static SSLContext createSslContext() throws Exception {
        KeyStore ks = KeyStore.getInstance("JKS");
        try (var in = NioTlsServer.class.getClassLoader().getResourceAsStream(KEYSTORE_PATH)) {
            ks.load(in, KEYSTORE_PASSWORD.toCharArray());
        }

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, KEYSTORE_PASSWORD.toCharArray());

        SSLContext context = SSLContext.getInstance("TLS");
        context.init(kmf.getKeyManagers(), null, null);
        return context;
    }

    private static void handleAccept(ServerSocketChannel serverChannel, Selector selector, SSLContext sslContext)
            throws IOException {
        SocketChannel clientChannel = serverChannel.accept();
        if (clientChannel == null) return;

        clientChannel.configureBlocking(false);
        SSLEngine sslEngine = sslContext.createSSLEngine();
        sslEngine.setUseClientMode(false); // 服务器模式
        sslEngine.setNeedClientAuth(false); // 如需双向认证设为 true

        // 创建连接上下文对象
        TlsConnection conn = new TlsConnection(clientChannel, sslEngine);
        clientChannel.register(selector, SelectionKey.OP_READ, conn);

        // 开始 TLS 握手
        conn.beginHandshake();
    }

    private static void handleRead(SelectionKey key) throws IOException {
        TlsConnection conn = (TlsConnection) key.attachment();
        try {
            conn.read();
        } catch (Exception e) {
            e.printStackTrace();
            closeConnection(key);
        }
    }

    private static void handleWrite(SelectionKey key) throws IOException {
        TlsConnection conn = (TlsConnection) key.attachment();
//        try {
//            conn.writePending();
//        } catch (Exception e) {
//            e.printStackTrace();
//            closeConnection(key);
//        }
    }

    private static void closeConnection(SelectionKey key) {
        try {
            key.channel().close();
        } catch (IOException ignored) {}
        key.cancel();
    }
}